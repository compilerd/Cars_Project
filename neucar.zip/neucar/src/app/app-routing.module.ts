import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SignupComponent} from './signup/signup.component'
import {HomepageComponent} from './homepage/homepage.component'


const routes: Routes = [
  {path:'SignUp' , component: SignupComponent},
  {path:"HomePage", component:HomepageComponent},
  { path: '', redirectTo: '/homepage', pathMatch: 'full' },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
